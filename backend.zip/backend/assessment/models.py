'''
This module contains the models for the assessment app.
'''

from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from courses.models import Course, Task

class Submission(models.Model):
    '''
    Model representing a submission for an assessment task.
    Attributes:
        user (ForeignKey): Reference to the user who made the submission.
        task (ForeignKey): Reference to the task being submitted.
        submitted_at (DateTimeField): Timestamp when the submission was made.
        content (TextField): Content of the submission.
        grade (DecimalField): Grade assigned to the submission.
    Methods:
        get_username() -> str:
            Safely retrieve the username from the related user.
        get_task_title() -> str:
            Safely retrieve the task title.
        __str__() -> str:
            Return a string representation of the submission in the format "username - task title".
    '''
    class Meta:
        app_label = 'assessment'

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='submissions'
    )
    task = models.ForeignKey(
        Task, 
        on_delete=models.CASCADE, 
        related_name='submissions'
    )
    submitted_at = models.DateTimeField(auto_now_add=True)
    content = models.TextField(
        _('Submission Content'), 
        blank=True
    )
    grade = models.DecimalField(
        _('Grade'), 
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True
    )

    objects = models.Manager()

    def get_username(self) -> str:
        """
        Safely retrieve username from related user
        """
        try:
            return str(self.user.username) if self.user else ''
        except AttributeError:
            return ''

    def get_task_title(self) -> str:
        """
        Safely retrieve task title
        """
        try:
            return str(self.task.title) if self.task else ''
        except AttributeError:
            return ''

    def __str__(self) -> str:
        return f"{self.get_username()} - {self.get_task_title()}"

class UserProgress(models.Model):
    class Meta:
        app_label = 'assessment'
        unique_together = ('user', 'course')

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='progress'
    )
    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE, 
        related_name='user_progress'
    )
    completed_tasks = models.ManyToManyField(
        Task, 
        related_name='completed_by'
    )
    total_score = models.DecimalField(
        _('Total Score'), 
        max_digits=5, 
        decimal_places=2, 
        default=0
    )
    is_completed = models.BooleanField(default=False)

    objects = models.Manager()

    def get_username(self) -> str:
        """
        Safely retrieve username from related user
        """
        try:
            return str(self.user.username) if self.user else ''
        except AttributeError:
            return ''

    def get_course_title(self) -> str:
        """
        Safely retrieve course title
        """
        try:
            return str(self.course.title) if self.course else ''
        except AttributeError:
            return ''

    def __str__(self) -> str:
        return f"{self.get_username()} - {self.get_course_title()}"
