from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from typing import Optional

class Course(models.Model):
    """
    Model representing a course.
    """
    class Meta:
        app_label = 'courses'

    title = models.CharField(
        _('Course Title'), 
        max_length=200, 
        unique=True
    )
    description = models.TextField(
        _('Course Description'), 
        blank=True
    )
    instructor = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        related_name='courses_taught',
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = models.Manager()

    def __str__(self) -> str:
        """
        String representation of the Course model.
        """
        return self.title or ''

class Task(models.Model):
    """
    Model representing a task within a course.
    """
    class Meta:
        app_label = 'courses'

    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE, 
        related_name='tasks'
    )
    title = models.CharField(
        _('Task Title'), 
        max_length=200
    )
    description = models.TextField(
        _('Task Description'), 
        blank=True
    )
    due_date = models.DateTimeField(null=True, blank=True)

    objects = models.Manager()

    def __str__(self) -> str:
        """
        String representation of the Task model.
        """
        return f"{self.course.title or ''} - {self.title or ''}"
