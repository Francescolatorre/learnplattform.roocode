import sys
import os

# Get the project root directory
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Remove project root from sys.path if it exists
if project_root in sys.path:
    sys.path.remove(project_root)

# Add only the backend directory
backend_dir = os.path.dirname(os.path.abspath(__file__))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

print("Modified sys.path:", sys.path)