import sys
import os
import pytest

def _setup_pythonpath():
    """Set up the Python path with only the required directories."""
    # Get the project root and backend directories
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(backend_dir)
    
    # Start with a clean sys.path
    sys.path[:] = []
    
    # Add only the essential paths in the order we want
    paths = [
        backend_dir,  # Our backend directory first
        os.path.join(project_root, 'venv', 'Lib', 'site-packages'),  # site-packages
        os.path.join(os.path.dirname(sys.executable), 'DLLs'),  # Python DLLs
        os.path.dirname(sys.executable),  # Python installation
    ]
    
    # Add only existing paths
    sys.path.extend(p for p in paths if os.path.exists(p))

def pytest_load_initial_conftests(early_config, parser, args):
    """Set up path before any test collection or importing happens."""
    _setup_pythonpath()
    print("\nInitial sys.path setup:")
    for path in sys.path:
        print(f"  {path}")
    print()

def pytest_configure(config):
    """Verify path setup after configuration."""
    print("\nVerifying sys.path after configure:")
    for path in sys.path:
        print(f"  {path}")
    print()