from django.apps import AppConfig


class LearningunitsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "learningunits"
