# Backend package initialization
# This file ensures the backend directory is recognized as a Python package
# and allows for absolute imports across the project